# Çılgın Asistan v0.2 — ekran kapalı dinleme denemesi

Bu sürüm, Android'de görünür bir foreground service üzerinden Türkçe konuşma tanımayı döngü halinde sürdürmeyi DENER. “Çılgın” sözcüğü algılanınca “Buradayım Osman, seni dinliyorum” der ve bir sonraki cümleyi komut olarak yorumlar.

## Komutlar
- “Çılgın” ardından “YouTube'da araba videoları ara”
- “Çılgın” ardından “WhatsApp'ı aç”
- “Çılgın” ardından “alarmı aç”
- “Çılgın” ardından “Ahmet'i ara” — bu prototip yalnızca telefon arama ekranını açar; kişiyi otomatik seçmez.

## Önemli sınırlamalar
- Bu, test edilmemiş bir geliştirme prototipidir; kesintisiz çalışacağı garanti edilmez.
- Android `SpeechRecognizer` sürekli açık bir uyandırma-kelimesi motoru değildir. Bazı cihazlarda/Android sürümlerinde arka planda, kilit ekranında veya ekran kapalıyken tanıma kesilebilir.
- Güvenilir üretim sürümü için yerel keyword-spotting motoru (ör. lisans/uyumluluk kontrolüyle Porcupine veya uygun açık kaynak model), izin/servis yönetimi, Realme pil optimizasyonu testleri ve daha sağlam komut eşleştirme gerekir.
- Mikrofon kullanımı görünür kalıcı bildirimle gösterilir. Kullanıcı dinlemeyi uygulamadan durdurabilir.
- Android Studio ile açıp derle. `Build > Build APK(s)` ile APK oluşturulabilir. Bu paketin içinde önceden derlenmiş APK yoktur.
