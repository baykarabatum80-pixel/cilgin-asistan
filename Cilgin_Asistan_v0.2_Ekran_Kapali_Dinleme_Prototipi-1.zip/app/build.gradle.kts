plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.osman.cilgin"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.osman.cilgin"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "0.2"
    }
}
