package com.osman.cilgin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.net.URLEncoder
import java.util.Locale

class ListeningService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var commandMode = false
    private var restarting = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1, buildNotification("Türkçe uyandırma kelimesini bekliyor"))
        tts = TextToSpeech(this, this)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Cilgin::Listening").apply {
            setReferenceCounted(false)
            acquire()
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
            listenForWakeWord()
        } else {
            updateNotification("Bu telefonda ses tanıma hizmeti bulunamadı")
        }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("tr", "TR")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("cilgin_listening", "Çılgın dinleme", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "cilgin_listening")
                .setContentTitle("Çılgın Asistan")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Çılgın Asistan").setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(open)
                .setOngoing(true).build()
        }
    }

    private fun updateNotification(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(text))
    }

    private fun listenForWakeWord() {
        commandMode = false
        updateNotification("“Çılgın” kelimesini bekliyor")
        startRecognition()
    }

    private fun listenForCommand() {
        commandMode = true
        updateNotification("Seni dinliyor: komutunu söyle")
        speak("Buradayım Osman, seni dinliyorum.")
        startRecognition()
    }

    private fun startRecognition() {
        if (restarting) return
        restarting = true
        try {
            recognizer?.cancel()
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            updateNotification("Ses tanıma başlatılamadı; tekrar deneniyor")
            scheduleRetry()
        } finally {
            restarting = false
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) { scheduleRetry() }
        override fun onResults(results: android.os.Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val phrase = matches?.firstOrNull()?.lowercase(Locale("tr", "TR")).orEmpty()
            if (!commandMode) {
                if (phrase.contains("çılgın") || phrase.contains("cilgin")) {
                    listenForCommand()
                } else scheduleRetry()
            } else {
                if (phrase.isNotBlank()) handleCommand(phrase)
                commandMode = false
                scheduleRetry()
            }
        }
        override fun onPartialResults(partialResults: android.os.Bundle?) {
            if (!commandMode) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val phrase = matches?.firstOrNull()?.lowercase(Locale("tr", "TR")).orEmpty()
                if (phrase.contains("çılgın") || phrase.contains("cilgin")) {
                    try { recognizer?.cancel() } catch (_: Exception) {}
                    listenForCommand()
                }
            }
        }
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    }

    private fun scheduleRetry() {
        android.os.Handler(mainLooper).postDelayed({
            if (recognizer != null) {
                try { recognizer?.cancel() } catch (_: Exception) {}
                if (commandMode) listenForCommand() else listenForWakeWord()
            }
        }, 900)
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cilgin_reply")
        updateNotification(text)
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("youtube") -> {
                val query = command.replace("youtube", "")
                    .replace("aç", "").replace("arama kısmına", "")
                    .replace("ara", "").replace("yaz", "")
                    .replace("video", "").replace("videoyu", "")
                    .replace("oynat", "").trim()
                val url = "https://www.youtube.com/results?search_query=" +
                    URLEncoder.encode(query.ifBlank { "popüler videolar" }, "UTF-8")
                speak("YouTube aramasını açıyorum.")
                launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
            command.contains("whatsapp") -> {
                speak("WhatsApp'ı açıyorum.")
                val intent = packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (intent != null) launch(intent) else speak("WhatsApp bu telefonda kurulu değil.")
            }
            command.contains("alarm") -> {
                speak("Alarm ekranını açıyorum.")
                launch(Intent(android.provider.AlarmClock.ACTION_SHOW_ALARMS))
            }
            command.startsWith("ara ") || command.contains("telefon et") || command.contains("ara beni") -> {
                speak("Arama ekranını açıyorum. Bu sürümde kişiyi sen seçmelisin.")
                launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
            }
            else -> speak("Bu komutu henüz bilmiyorum. YouTube, WhatsApp veya alarm komutunu deneyebilirsin.")
        }
    }

    private fun launch(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { speak("Bu işlem şu anda açılamıyor.") }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        tts?.shutdown()
        tts = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
