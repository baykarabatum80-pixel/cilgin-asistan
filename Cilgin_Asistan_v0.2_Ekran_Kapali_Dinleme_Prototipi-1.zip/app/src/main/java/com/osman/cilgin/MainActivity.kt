package com.osman.cilgin

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val requestCode = 900

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 32)
            setBackgroundColor(0xFFF8F7FC.toInt())
        }
        val title = TextView(this).apply {
            text = "ÇILGIN"
            textSize = 32f
            setTextColor(0xFF35265F.toInt())
        }
        val desc = TextView(this).apply {
            text = "Türkçe sesli telefon asistanı"
            textSize = 18f
            setPadding(0, 12, 0, 22)
        }
        status = TextView(this).apply {
            text = "Hazır bekleme hizmetini başlatmak için aşağıya dokun."
            textSize = 16f
            setPadding(0, 0, 0, 22)
        }
        val start = Button(this).apply {
            text = "🎙 Çılgın'ı hazır kıtaya al"
            setOnClickListener { checkAndStart() }
        }
        val stop = Button(this).apply {
            text = "Dinlemeyi durdur"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ListeningService::class.java))
                status.text = "Çılgın dinlemeyi durdurdu."
            }
        }
        val note = TextView(this).apply {
            text = "Önemli: Android, ekran kilitliyken mikrofon kullanımını sınırlayabilir. Bu sürüm, görünür bildirimle arka planda dinlemeyi deneyecek; her cihazda kesintisiz çalışma garantisi yoktur. Türkçe ses tanıma hizmeti gerekir."
            textSize = 14f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title); layout.addView(desc); layout.addView(status)
        layout.addView(start); layout.addView(stop); layout.addView(note)
        setContentView(layout)
    }

    private fun checkAndStart() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = permissions.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
        } else startListener()
    }

    private fun startListener() {
        val intent = Intent(this, ListeningService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            status.text = "Çılgın başlatıldı. Bildirim alanında çalıştığını kontrol et."
        } catch (e: Exception) {
            status.text = "Başlatılamadı: ${e.localizedMessage ?: "Android izin kısıtlaması"}"
            Toast.makeText(this, status.text, Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startListener()
        else status.text = "Mikrofon ve bildirim izinleri olmadan dinleme başlatılamaz."
    }
}
